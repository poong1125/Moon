//package projectPackage;
//
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JPanel;
//
//public class ActionHandler implements ActionListener {
//
//
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		if(e.getActionCommand().equals("")) {
//			System.out.println("아");
//		}
//	}
//}