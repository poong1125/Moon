//package projectPackage;
//
//public class SessionManager {
//	private static UserInfoVo currentUser;
//
//	public static void setCurrentUser(UserInfoVo user) {
//		currentUser = user;
//	}
//
//	public static UserInfoVo getCurrentUser() {
//		return currentUser;
//	}
//
//	public static void clearSession() {
//		currentUser = null;
//	}
//}
