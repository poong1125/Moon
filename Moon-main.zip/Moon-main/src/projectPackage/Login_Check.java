//package projectPackage;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class Login_Check {
//	
//	private UserInfo_DAO dao;
//	ArrayList<UserInfoVo> Loged_User;
//
//	public void Set_Loged_User(List<Integer> User_No) {
//		dao = new UserInfo_DAO();
//		Loged_User = dao.User_no(User_No);
//		System.out.println("현재" + Loged_User + "로 로그인이 되었습니다.");
//	}
//}
////