package testProject;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("new Project Test!");
		System.out.println("완료");
		System.out.println("문승호 커밋입니다");
	}
}
